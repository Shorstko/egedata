//udata: 0=>RU, 1=>idval, 2=>banpos, 3=>server, 4=>curcluster, 5=>showWorkWrapper, 6=>childcat, 7=>politiccat, 8=>warezcat, 9=>allowNativeRoll, 10=>is_doubtful, 11=>is_abandoned, 12=>allowCriteo970, 13=>iabcat, 14=>religioncat, 15=>warncat, 16=>show_google
var crtads=0;
var crtads970=0;
var uw=crtg_content.split(/; */);
var uwlen=uw.length;
for (var i=0;i<uwlen;i++){
	if(typeof(criteo_params.rta970)!='undefined' && uw[i]==criteo_params.rta970) {
		crtads970=1;
	}
	if(uw[i]==criteo_params.rta){
		crtads=1;
	}
}

//костыль для гугл-цепочки: если критео выкупает, не показываем видео, чтобы позже показалось критео
// if(u_data[16] == 1 && (crtg_content.indexOf('crucz970p') >= 0 || crtg_content.indexOf('cruczn640') >= 0)) {
// 	ucoz_prerollenable = false ;
// }
//костыль для гугл-цепочки: снимаем видео с нее
if(u_data[16] == 1) {
	ucoz_prerollenable = false ;
}

if(ucoz_prerollenable && user_country == 'ru') {
	var uMggGeo = uPreroll.geo.city+' '+uPreroll.geo.region ;
	try { localStorage.setItem('uPrerollGeo' , uMggGeo) ; } catch(e){};
	window.uIsMskSpb = uMggGeo.indexOf('Moskov')>=0 || uMggGeo.indexOf('Moskva')>=0 || uMggGeo.indexOf('Moscow')>=0 || uMggGeo.indexOf('Saint')>=0 || uMggGeo.indexOf('Sankt')>=0 || location.search == "?utag_ismoscow" ;
	window.uIsMggRegion = uMggGeo.indexOf('Kazan')>=0 || uMggGeo.indexOf('Tatarstan')>=0 || uMggGeo.indexOf('Krasnodar')>=0 || location.search == "?utag_iskazan" ;
	window.uIsMggInbodyRegion = uMggGeo.indexOf('Yekaterinburg')>=0 || uMggGeo.indexOf('Sverdlovs')>=0 || location.search == "?utag_isekb" ;
	window.uShowVidRand = Math.random() ;
	window.uShowAdwise = uShowVidRand < 0.15 ;
	window.uShowMggcont = (uShowVidRand >= 0.15 && !uIsMskSpb) || uIsMggInbodyRegion ;

	if( !(uShowMggcont || uIsMggRegion || u_data[11]=='1' || uShowAdwise) ) {
		//не казань, не краснодар, не 5% адвайса
		ucoz_prerollenable = false ;
		uPreroll_setcookie() ;
	}
}


if(u_data[10]=='1') {
	//adult banner
	document.getElementById('bannerY'+ucoz_rndid).value=435;
	document.getElementById('bannerX'+ucoz_rndid).value=240;
	var script_ads = document.createElement("script");
	script_ads.src = 'http://rot.spotsniper.ru/?src=ujs1&s_subid=adlt';
	document.head.appendChild(script_ads);
	uShowFloatBanner() ;
	uOnDomOrLater(addUcozWrappers) ;
} else if(!criteo_params.no_criteo && u_data[12]=='1' && crtads970 && u_data[6]!='1' && u_data[16]!=1) {
	//970x250 criteo rtb banner
	(function(){
		//обертка
		var style = document.createElement('style');
		style.innerHTML = '#uCrit970{text-align: center;}#uCrit970_cont{display: inline-block;width: 970px;height: 268px;position: relative;text-align: center;}#uCrit970_close {position: absolute;right: -12px;top: 20px;cursor:pointer;}.adv-remove {display: block;text-align: center !important;background: url(//'+ucoz_server+'.ucoz.net/ucoz/img/uads/a-buttons-logged.gif) repeat-x !important;padding: 0 10px !important;margin: 0 !important;font: bold 9px/18px \'Tahoma\', \'Arial\' !important;color: #fff !important;text-decoration: none !important;text-transform: uppercase;border-radius: 0 0 3px 3px;}' ;
		document.body.appendChild(style);
		var uCrit970 = document.createElement('div');
		uCrit970.id = 'uCrit970';
		document.body.insertBefore(uCrit970 , document.body.firstChild) ;
		var uCrit970_cont = document.createElement('div');
		uCrit970_cont.id = 'uCrit970_cont';
		uCrit970.appendChild(uCrit970_cont);
		uCrit970_cont.innerHTML = '<img src="//'+ucoz_server+'.ucoz.net/img/ma/cv.gif" id="uCrit970_close" />'+
			'<div style="position:absolute;bottom:0px;left:0px;text-align:left;width: 100%;z-index: 1;cursor:pointer;" onclick="event.stopPropagation();"><a href="javascript://" onclick="new _uWnd(\'UBROWSERDOWNLOAD\',\'Отключение рекламы\',-550,-400,{popup:1,modal:1,resize:0,autosize:0,align:\'justify\'},\'<div id=&quot;ads_window&quot; class=&quot;ads_window&quot;></div><style type=&quot;text/css&quot;>.xw-active, .x-sh{display:none;} div.myWinGrid{z-index:2147483642!important;height:100%!important;}div.uwnd-uran-br{z-index:2147483643!important;}div.uwnd-uran-br div.xw-plain{width: auto !important;}div#_umenu0{z-index:2147483644!important;}</style><script type=&quot;text/javascript&quot; src=&quot;http://cdn.uranupdates.com/popup2/uadsoff6.js&quot;></scr\'+\'ipt>\');return false;" title="Отключить рекламу на всех сайтах системы uCoz" class="adv-remove"><span>Убрать рекламный баннер</span></a></div>' ;
		document.getElementById('uCrit970_close').addEventListener('click' , function(){
			document.getElementById('uCrit970').remove();
		});
		document.getElementById(ucoz_rndid).style.display='none';
		uLiruCounter('criteo_970_250');

		//сам баннер
		var bnrdiv = document.createElement('div');
		bnrdiv.id = 'criteo_zoneid_'+criteo_params.zoneid970;
		bnrdiv.style.margin = '0px';
		uCrit970_cont.appendChild(bnrdiv);
		var crt_zoneid = criteo_params.zoneid970;
		var crt_curl = '#CLICK_URL_UNESC#';
		(function(w,d,s,c,z,u){var f=d.getElementsByTagName(s)[0],
			j=d.createElement(s),l = '&loc=' + encodeURIComponent(w.location), r = d.referrer ? '&referer=' + encodeURIComponent(d.referrer) : '', g = u.substring(0,4) == 'http' ? '&ct0='+encodeURIComponent(u) : '', cb="&cb="+Math.floor(Math.random()*99999999999) ;j.async='true';j.src=(("https:"==location.protocol?"https:":"http:")+
			'//cas.criteo.com/delivery/ajs.php?zoneid='+z+'&containerid='+c+g+l+r+cb).substring(0,2000);f.parentNode.insertBefore(j,f);
		})(window,document,'script','criteo_zoneid_'+criteo_params.zoneid970,crt_zoneid,crt_curl);
	})();
} else if(!criteo_params.no_criteo && crtads && u_data[16]!=1){
	//criteo rtb banner
	if(u_data[6]=='1') crtads970 = 0 ;
	document.getElementById('bannerY'+ucoz_rndid).value=400;
	document.getElementById('bannerX'+ucoz_rndid).value=240;

	var bnrdiv = document.createElement('div');
	bnrdiv.id = 'criteo_zoneid_'+criteo_params.zoneid;
	bnrdiv.style.margin = '0px';
	document.getElementById('mainadsdv' + ucoz_rndid).appendChild(bnrdiv);
	var crt_zoneid = criteo_params.zoneid;
	var crt_curl = '#CLICK_URL_UNESC#';
	(function(w,d,s,c,z,u){var f=d.getElementsByTagName(s)[0],
		j=d.createElement(s),l = '&loc=' + encodeURIComponent(w.location), r = d.referrer ? '&referer=' + encodeURIComponent(d.referrer) : '', g = u.substring(0,4) == 'http' ? '&ct0='+encodeURIComponent(u) : '', cb="&cb="+Math.floor(Math.random()*99999999999) ;j.async='true';j.src=(("https:"==location.protocol?"https:":"http:")+
		'//cas.criteo.com/delivery/ajs.php?zoneid='+z+'&containerid='+c+g+l+r+cb).substring(0,2000);f.parentNode.insertBefore(j,f);
	})(window,document,'script','criteo_zoneid_'+criteo_params.zoneid,crt_zoneid,crt_curl);

	uLiruCounter(ucoz_site_type == 'ucoz' ? 'criteo_rta':'audit_criteo_narod');
	uShowFloatBanner() ;
	uOnDomOrLater(addUcozWrappers) ;
} else if(ucoz_prerollenable) {
	//preroll
	// document.getElementById('wrapperX'+ucoz_rndid).value=0;
	// document.getElementById('wrapperY'+ucoz_rndid).value=0;
	document.getElementById('dV'+ucoz_rndid).style.overflow='';
	var style = document.createElement('style');
	style.id = "hideAdBlock240x400" ;
	style.innerHTML = '#'+ucoz_rndid+' .a-buttons.green-but.a-clock, #'+ucoz_rndid+' .a-buttons.blue-but.a-check, #'+ucoz_rndid+' td[valign="top"]{display: none!important}' ;
	document.getElementsByTagName('head')[0].appendChild(style);

	var script_wrapper = document.createElement("script");
	script_wrapper.src = 'http://rot.spotsniper.ru/?src=ucfs&s_subid='+(u_data[5] ? 'videobtmwrpwork' : 'videobtmwrp');
	script_wrapper.onload = script_wrapper.onerror = function(){
		if(uPreroll.init_gae_done) {
			uPreroll.init_btm_wrapper();
		} else {
			uPreroll.init_btm_wrapper_ready = true ;
		}
	};
	document.head.appendChild(script_wrapper);

	var script_video = document.createElement("script");
	if(user_country == 'ru') {
		script_video.src = '//'+(ucoz_server=='s55555' ? 'sdev022.ucozmedia.com' : ucoz_server+'.ucoz.net')+'/bnr/blocks/preroll_ru.js?r'+Math.random() ;
		uLiruCounter('preroll_total_ru');
	} else {
		if(u_data[15]=='1')
			script_video.src = 'http://rot.spotsniper.ru/?src=ucfs&s_subid=warn' ;
		else if(u_data[8]=='1')
			script_video.src = 'http://rot.spotsniper.ru/?src=ucfs&s_subid=trrnt' ;
		else if(u_data[7]=='1')
			script_video.src = 'http://rot.spotsniper.ru/?src=ucfs&s_subid=pltcs' ;
		else if(u_data[14]=='1')
			script_video.src = 'http://rot.spotsniper.ru/?src=ucfs&s_subid=rlgn' ;
		else if(u_data[6]=='1')
			script_video.src = 'http://rot.spotsniper.ru/?src=ucfs&s_subid=kids' ;
		else if(u_data[11]=='1')
			script_video.src = 'http://rot.spotsniper.ru/?src=ucfs&s_subid=abnd' ;
		else //нормальное видео
			script_video.src = 'http://rot.spotsniper.ru/?src=ucfs' ;
	}
	document.head.appendChild(script_video);

	uLiruCounter(ucoz_site_type == 'ucoz' ? 'preroll_total_ucoz':'preroll_total_narod');
	uNewMyCounter('preroll_all');
	uPreroll_setcookie() ;

	//плавающий формат вместе с фулскрином
	if(u_data[11]!='1' && u_data[6]!='1') {
		var script_additional = document.createElement("script");
		if(u_data[7]=='1' || u_data[8]=='1' || u_data[14]=='1' || u_data[15]=='1') {
			script_additional.src = "http://rot.spotsniper.ru/?src=ujs1&s_subid=plusfull2" ;
		} else {
			script_additional.src = "http://rot.spotsniper.ru/?src=ujs1&s_subid=plusfull1" ;
		}
		document.head.appendChild(script_additional);
	}
} else if(u_data[16]==1) { //google
	document.getElementById('wrapperX'+ucoz_rndid).value=0;
	document.getElementById('wrapperY'+ucoz_rndid).value=0;
	var style = document.createElement('style');
	style.id = "hideAdBlock240x400" ;
	style.innerHTML = '#'+ucoz_rndid+' .a-buttons.green-but.a-clock, #'+ucoz_rndid+' .a-buttons.blue-but.a-check, #'+ucoz_rndid+' td[valign="top"]{display: none!important}' ;
	document.body.appendChild(style);

	uOnDomOrLater(function() {
		console.log('show google');
		ucoz_body_rndbart = ucoz_rndid ;
		ucoz_is_mobile = 0 ;
		if($('#nativeroll_video_cont').length > 0) {
			$('#nativeroll_video_cont').show();
			$('#nativeroll_video_cont').parents().show();
			$('#nativeroll_video_cont').append('<div id="wprdv'+ucoz_body_rndbart+'" style="text-align: center; overflow:hidden;"><div id="ads_games_parent'+ucoz_body_rndbart+'" style="display: inline-block;line-height:0;"><div id="ads_cont_'+ucoz_body_rndbart+'"></div></div></div>');
			$.getScript('//'+(ucoz_server=='s55555' ? 'sdev022.ucozmedia.com' : ucoz_server+'.ucoz.net')+'/bnr/blocks/criteo_google.js' , function() {
				if(Math.random() < 0.6) {
					console.log('split google: criteo first');
					u_google_ads.criteo_google();
				} else {
					console.log('split google: no criteo');
					u_google_ads.ad_google({
						'client':'ca-pub-7652081594934001',
						'slot':'4363281816',
					});
				}
			});
		} else {
			uNewMyCounter('google_nodiv');
		}
	});
} else {
	//banner
	document.getElementById('bannerY'+ucoz_rndid).value=400;
	document.getElementById('bannerX'+ucoz_rndid).value=240;
	if(user_country == 'ru'){
		if(ucoz_site_type == 'ucoz') {
			uOnDomOrLater(function(){
				setTimeout('uShowRuAdBanner();',0);
			}) ;
		} else {
			uIfrAdBanner('<script>var adtagsParams_64ac0d5d = {"domainId":197,"description":"","pid":75,"size":{"width":240,"height":400}}</script><div id="adtagsParams_64ac0d5d"><script type="text/javascript" id="__sspicy__placement_init_558">(function(w, d, a, c, i) {(w[a] = w[a] || []).push({id: 558,params: {u_age: 0,u_gen: 0},extra_params: {},noiframe: false});if (d.getElementById(i)) {return;}var s, f;s = d.createElement(c);s.id = i;s.type = \'text/javascript\';s.async = true;s.src = "//static.sspicy.ru/theme/sspicy/adload_async.js";f = d.getElementsByTagName(c)[0];f.parentNode.insertBefore(s, f);})(window, document, \'__sspicy__placements\', \'script\', \'__sspicy__adload_lib\')</script></div><script src="https://cdn.adtags.pro/adtagsLoader.js" onload="adtagsLoader(\'adtagsParams_64ac0d5d\', adtagsParams_64ac0d5d)"></script>');
		}
		uShowFloatBanner();
	} else if(user_country == 'ua' || user_country == 'by' || user_country == 'kz'){
		var adcode = ucoz_site_type == 'ucoz' ?
			'<script>var adtagsParams_f22d7a6e = {"domainId":196,"description":"spicy id 622","pid":75,"size":{"width":240,"height":400}}</script><div id="adtagsParams_f22d7a6e"><script type="text/javascript" id="__sspicy__placement_init_622">(function(w, d, a, c, i) {(w[a] = w[a] || []).push({id: 622,params: {u_age: 0,u_gen: 0},extra_params: {},noiframe: false});if (d.getElementById(i)) {return;}var s, f;s = d.createElement(c);s.id = i;s.type = \'text/javascript\';s.async = true;s.src = "//static.sspicy.ru/theme/sspicy/adload_async.js";f = d.getElementsByTagName(c)[0];f.parentNode.insertBefore(s, f);})(window, document, \'__sspicy__placements\', \'script\', \'__sspicy__adload_lib\')</script></div><script src="https://cdn.adtags.pro/adtagsLoader.js" onload="adtagsLoader(\'adtagsParams_f22d7a6e\', adtagsParams_f22d7a6e)"></script>' :
			'<script>var adtagsParams_e991520c = {"domainId":198,"description":"spicy id 626","pid":75,"size":{"width":240,"height":400}}</script><div id="adtagsParams_e991520c"><script type="text/javascript" id="__sspicy__placement_init_626">(function(w, d, a, c, i) {(w[a] = w[a] || []).push({id: 626,params: {u_age: 0,u_gen: 0},extra_params: {},noiframe: false});if (d.getElementById(i)) {return;}var s, f;s = d.createElement(c);s.id = i;s.type = \'text/javascript\';s.async = true;s.src = "//static.sspicy.ru/theme/sspicy/adload_async.js";f = d.getElementsByTagName(c)[0];f.parentNode.insertBefore(s, f);})(window, document, \'__sspicy__placements\', \'script\', \'__sspicy__adload_lib\')</script></div><script src="https://cdn.adtags.pro/adtagsLoader.js" onload="adtagsLoader(\'adtagsParams_e991520c\', adtagsParams_e991520c)"></script>' ;
		uIfrAdBanner(adcode) ;
	} else {
		var code = '<script>var adtagsParams_a78cb6d9 = {"domainId":199,"description":"","pid":75,"size":{"width":240,"height":400}}</script><div id="adtagsParams_a78cb6d9"><div id="mainadsdv"></div></div><script src="https://cdn.adtags.pro/adtagsLoader.js" onload="adtagsLoader(\'adtagsParams_a78cb6d9\', adtagsParams_a78cb6d9)"></script><script>var user_country = "'+user_country+'";var ucoz_server = "'+ucoz_server+'";var ucoz_rndid = "";var ucoz_site_type = "'+ucoz_site_type+'" ;var ucoz_hostname = "'+location.hostname+'";var script_ads = document.createElement("script");script_ads.src = "http://rot.spotsniper.ru/?src=urt1&s_subid=b240x400_ru&s_w=240&s_h=400&s_subid1=show1&s_subid2=mainadsdv&s_dmn=" + ucoz_hostname ;document.head.appendChild(script_ads);</script>';
		uIfrAdBanner(code) ;
		uLiruCounter(ucoz_site_type == 'ucoz' ? 'supersniper_sng_ucoz':'supersniper_sng_narod') ;
	}
	uOnDomOrLater(addUcozWrappers) ;
}
uOnDomOrLater(resizeDiv);

//nativeroll
if(u_data[9]=='1' && u_data[10]!='1' && u_data[16]!=1) {
	var script_inbody = document.createElement("script");
	if(u_data[15]=='1')
		script_inbody.src = 'http://rot.spotsniper.ru/?src=ucfs&s_subid=inbodywarn' ;
	else if(u_data[8]=='1')
		script_inbody.src = 'http://rot.spotsniper.ru/?src=ucfs&s_subid=inbodytrrnt' ;
	else if(u_data[11]=='1')
		script_inbody.src = 'http://rot.spotsniper.ru/?src=ucfs&s_subid=inbodyabnd' ;
	else //нормальное видео
		script_inbody.src = 'http://rot.spotsniper.ru/?src=ucfs&s_subid=inbody' ;
	document.head.appendChild(script_inbody);
}

if(user_country == 'ru' && (u_data[15]=='1' || u_data[8]=='1' || u_data[7]=='1' || u_data[14]=='1')) {
	uLiruCounter('novideo_cats_ru');
}

function uShowFloatBanner(){
	if(u_data[11]!='1') {
		var script_additional = document.createElement("script");
		if(u_data[10]=='1' || u_data[7]=='1' || u_data[8]=='1' || u_data[14]=='1' || u_data[15]=='1') { //адалт, политика, варез и проч
			script_additional.src = 'http://rot.spotsniper.ru/?src=ujs1&s_subid=plus2402';
		} else if(u_data[6]=='1') { //детские
			script_additional.src = 'http://rot.spotsniper.ru/?src=ujs1&s_subid=plus2403';
		} else { //нормальные
			script_additional.src = 'http://rot.spotsniper.ru/?src=ujs1&s_subid=plus2401';
		}
		document.head.appendChild(script_additional);
	}
}

function uShowRuAdBanner() {
	window.catsplit_data = {} ;
	catsplit_data.all_codes = { //коды спайси в зависимости от РТБ-категории
		'1':{sspicy_code:'564',adtags_code:'45bf2b23',domainid:'167'} /*Arts & Entertainment*/ , '2':{sspicy_code:'567',adtags_code:'412017e9',domainid:'168'} /*Automotive*/ , '3':{sspicy_code:'569',adtags_code:'02570028',domainid:'169'} /*Business*/ ,
		'4':{sspicy_code:'570',adtags_code:'3fea1f63',domainid:'170'} /*Careers*/ , '5':{sspicy_code:'571',adtags_code:'f98c7522',domainid:'171'} /*Education*/ , '6':{sspicy_code:'572',adtags_code:'a1aa4dc1',domainid:'172'} /*Family & Parenting*/ ,
		'7':{sspicy_code:'573',adtags_code:'b897393e',domainid:'173'} /*Health & Fitness*/ , '8':{sspicy_code:'574',adtags_code:'b3e84fe3',domainid:'174'} /*Food & Drink*/ , '9':{sspicy_code:'575',adtags_code:'ad6a1c33',domainid:'175'} /*Hobbies & Interests*/ ,
		'10':{sspicy_code:'576',adtags_code:'c417d17a',domainid:'176'} /*Home & Garden = 10home*/ , '11':{sspicy_code:'577',adtags_code:'4923aeb4',domainid:'177'} /*Law, Government, & Politics*/ , '12':{sspicy_code:'578',adtags_code:'b6c72c7a',domainid:'178'} /*News*/ ,
		'13':{sspicy_code:'579',adtags_code:'99734dc5',domainid:'179'} /*Personal Finance*/ , '14':{sspicy_code:'580',adtags_code:'36fa2145',domainid:'180'} /*Society*/ , '15':{sspicy_code:'581',adtags_code:'c48613b2',domainid:'181'} /*Science*/ ,
		'16':{sspicy_code:'582',adtags_code:'e24f6b4b',domainid:'182'} /*Pets*/ , '17':{sspicy_code:'583',adtags_code:'a89d2388',domainid:'183'} /*Sports*/ , '18':{sspicy_code:'584',adtags_code:'bfed0d1e',domainid:'184'} /*Style & Fashion*/ ,
		'19':{sspicy_code:'585',adtags_code:'a3c7ee0c',domainid:'185'} /*Technology & Computing*/ , '20':{sspicy_code:'586',adtags_code:'57bb8697',domainid:'186'} /*Travel*/ , '21':{sspicy_code:'587',adtags_code:'e81e0eeb',domainid:'187'} /*Real Estate*/ ,
		'22':{sspicy_code:'588',adtags_code:'609eafba',domainid:'188'} /*Shopping*/ , '23':{sspicy_code:'589',adtags_code:'c1014afb',domainid:'189'} /*Religion & Spirituality*/ , '24':{sspicy_code:'590',adtags_code:'2851f161',domainid:'190'} /*Uncategorized*/ ,
		'25':'591' /*Non-Standard Content*/ , '26':'592' /*Illegal Content*/
	} ;
	catsplit_data.cat = u_data[13] ;
	if(catsplit_data.cat && catsplit_data.cat.indexOf('-')>=0) catsplit_data.cat = catsplit_data.cat.split('-')[0] ;
	if(!catsplit_data.all_codes[catsplit_data.cat]) catsplit_data.cat = '24'; //uncategorized

	if(typeof(catsplit_data.all_codes[catsplit_data.cat]) == "object") {
		console.log('spicy with wrapper');
		uIfrAdBanner('<script>var adtagsParams_'+catsplit_data.all_codes[catsplit_data.cat].adtags_code+' = {"domainId":'+catsplit_data.all_codes[catsplit_data.cat].domainid+',"description":"","pid":75,"size":{"width":240,"height":400}}</script><div id="adtagsParams_'+catsplit_data.all_codes[catsplit_data.cat].adtags_code+'"><script type="text/javascript" id="__sspicy__placement_init_'+catsplit_data.all_codes[catsplit_data.cat].sspicy_code+'">(function(w, d, a, c, i) {(w[a] = w[a] || []).push({id: '+catsplit_data.all_codes[catsplit_data.cat].sspicy_code+',params: {u_age: 0,u_gen: 0},extra_params: {},noiframe: false});if (d.getElementById(i)) {return;}var s, f;s = d.createElement(c);s.id = i;s.type = \'text/javascript\';s.async = true;s.src = "//static.sspicy.ru/theme/sspicy/adload_async.js";f = d.getElementsByTagName(c)[0];f.parentNode.insertBefore(s, f);})(window, document, \'__sspicy__placements\', \'script\', \'__sspicy__adload_lib\')</script></div><script src="https://cdn.adtags.pro/adtagsLoader.js" onload="adtagsLoader(\'adtagsParams_'+catsplit_data.all_codes[catsplit_data.cat].adtags_code+'\', adtagsParams_'+catsplit_data.all_codes[catsplit_data.cat].adtags_code+')"></script>') ;
	} else {
		console.log('spicy direct');
		var adcode = catsplit_data.all_codes[catsplit_data.cat] ;
		uIfrAdBanner('<script type="text/javascript" id="__sspicy__placement_init_'+adcode+'">(function(w, d, a, c, i) {(w[a] = w[a] || []).push({id: '+adcode+',params: {u_age: 0,u_gen: 0},extra_params: {},noiframe: false});if (d.getElementById(i)) {return;}var s, f;s = d.createElement(c);s.id = i;s.type = "text/javascript";s.async = true;s.src = "//static.sspicy.ru/theme/sspicy/adload_async.js";f = d.getElementsByTagName(c)[0];f.parentNode.insertBefore(s, f);})(window, document, "__sspicy__placements", "script", "__sspicy__adload_lib")</script>') ;
	}
	uLiruCounter('spicy_ucoz');

	if(catsplit_data.cat == '24') uLiruCounter('spicy_ucoz_24_590');
	if(catsplit_data.cat == '26') uLiruCounter('spicy_ucoz_26_592');

	if(
		(ucoz_prerollenable && uShowMggcont)
		|| (!ucoz_prerollenable && u_data[9]=='1' && u_data[10]!='1' && u_data[16]!=1)
	) {
		var uPrerollGeo = '' ;
		try { uPrerollGeo = '' + localStorage.getItem('uPrerollGeo') ; } catch(e){};
		var uIsMskSpb = uPrerollGeo.indexOf('Moskov')>=0 || uPrerollGeo.indexOf('Moskva')>=0 || uPrerollGeo.indexOf('Moscow')>=0 || uPrerollGeo.indexOf('Saint')>=0 || uPrerollGeo.indexOf('Sankt')>=0 ;
		if(u_data[15]!='1' && u_data[8]!='1' && u_data[7]!='1' && u_data[14]!='1' && !uIsStopWord() && u_data[13]!='3' && !uIsMskSpb) {
			var el = $('#nativeroll_video_cont') ;
			if (el.length > 0) {
				el.show();
				el.parents().show();
				if(el.width() >= 600) {
					uNewMyCounter('mgg_like_traf');
				}
			}
		}
	}
}

if(ucoz_site_type == 'narod') {
	uOnDomOrLater(function(){
		//jQuery и uwnd на статику народа
		if (typeof jQuery == 'undefined') {
			var scrpt = document.createElement('script');
			scrpt.src = '//'+ucoz_server+'.ucoz.net/src/jquery-1.7.2.js';
			scrpt.onload = function(){
				var scrpt2 = document.createElement('script');
				scrpt2.src = '//'+ucoz_server+'.ucoz.net/src/uwnd.js';
				document.head.appendChild(scrpt2);
			}
			document.head.appendChild(scrpt);
		} else {
			if (typeof _uWnd == 'undefined') {
				var scrpt = document.createElement('script');
				scrpt.src = '//'+ucoz_server+'.ucoz.net/src/uwnd.js';
				document.head.appendChild(scrpt);
			}
		}
	});
}

function uLiruCounter(counter){
	new Image().src = "//counter.yadro.ru/hit;"+counter+"?r"+escape(document.referrer)+((typeof(screen)=="undefined")?"":";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?screen.colorDepth:screen.pixelDepth))+";u"+escape(document.URL)+";"+Math.random();
}
function uNewMyCounter(counter , unique , dT) {
	var add = '' ;
	if(unique) add += '&uq='+encodeURIComponent(unique) ;
	if(dT) add += '&dt='+encodeURIComponent(dT) ;
	new Image().src="http://188.120.226.43/stat/pixel.gif?host=ucoz&event="+counter+add+"&r="+Math.random();
}
function uIfrAdBanner(code) {
	var frames = document.getElementById('mainadsdv' + ucoz_rndid).getElementsByTagName('iframe');
	if(frames[0]) frames[0].remove();
	var bnr_iframe = document.createElement('iframe');
	bnr_iframe.setAttribute('frameborder', '0');
	bnr_iframe.setAttribute('style', 'width:240px;height:400px;');
	document.getElementById('mainadsdv' + ucoz_rndid).appendChild(bnr_iframe);
	bnr_iframe.contentWindow.document.open();
	bnr_iframe.contentWindow.document.write('<html><head>');
	bnr_iframe.contentWindow.document.write('<style>body{margin:0;}</style>');
	bnr_iframe.contentWindow.document.write('</head><body>');
	bnr_iframe.contentWindow.document.write(code);
	bnr_iframe.contentWindow.document.write('</body></html>');
	bnr_iframe.contentWindow.document.close();
}
function uIsStopWord() {
	return location.hostname.search(
		"elektromusic.clan.su|adult|allah|allah|anal|baptist|baptist|bdsm|bible|biblija|bisex|blowjob|bondage|brazzers|breast"+
		"|buddhism|buddizm|catholic|catholicism|cekc|cerkov|chicks|christ|christian|church|clairvoyance|clitoris|copro|devstvennost"+
		"|dick|divination|dojki|eblya|ecstasy|ekstas|elektromusic.clan.su|erotic|erotik|erotika|erect|fantasti|fetish|filestube"+
		"|fisting|gadanie|gangbang|gay|gey|handjob|hardcore|hentai|hinduism|hram|hristianin|hristianstvo|hristos|iclam|iegova|iisus"+
		"|induizm|intercourse|islam|iudaizm|iuedi|iuedi|jasnovid|jehovah|jekstasensornyj|jesus|judaism|katolicheskij|katolichestvo"+
		"|kiss|koran|lesbian|lesby|lick|ljuteran|lolita|lutheran|lutheran|magomed|magomed|masturbacija|masturbation|messing|milf"+
		"|minet|muhammad|muhammed|muslim|musulmanin|musulmanstvo|naked|nude|orgasm|orthodox|paranormalnyj|penetration|penetration"+
		"|pisanie|pizda|pizdenka|porevo|porn|pornhub|porno|porntube|pornuha|potaskushka|pravoslavie|pravoslavnyj|prophet|prorok"+
		"|prostitute|protestant|protestant|psalter|psaltyr|pussy|redtube|rectal|religija|religion|religious|religioznyj|sadism"+
		"|saentologija|scientolog|seks|sekta|sex|sexual|sexuality|siski|slutload|spankwire|sperma|spiritualizm|striptease|svjashhen"+
		"|telepat|temple|tits|torent|torrent|trah|trax|tserkov|vanga|virgin|whore|xhamster|xnxx|xvideos|xxx|intim|prostitut|sosut"+
		"|iznasilovanie|zhop|junye_pisi|ehrotich|oralnij|13demons|13game|ehrotik|ehrotik|bilmed"
	) >= 0 ;
}

/*
// тест видео-кнопки на списке сайтов
(function() {
	var sites = ['dev022.ucozmedia.com','ymka.tv','ua.at.ua','ani-3gp.3dn.ru','kinox-online.my1.ru','kinoglobus.at.ua','amour.3dn.ru',
	'jetix-base.ucoz.com','kinosal.at.ua','fazik.ucoz.net','kino-forum.do.am','polkardana.ucoz.net','onliene-kino.at.ua',
	'salambek.clan.su','sromline.my1.ru','ka.my1.ru','kino-onlaun.ucoz.ru','filmyonline.ucoz.com','kinokrit.ucoz.ru',
	'film-online.3dn.ru','mixfilms.at.ua','netfilmi.ucoz.net','kinogolos.ucoz.ru','kinobos.ucoz.org','kinobum.ucoz.ua',
	'kino-sib.ucoz.ru','atas.ucoz.com','talgar-cs.ucoz.kz','kinoshare.3dn.ru','me4-film.moy.su','kinosmotr.ucoz.net',
	'on-movie.clan.su','terranova.do.am','lsbo.ucoz.ua','mobilesity.ucoz.ru','filmobum.clan.su','top-kino.3dn.ru',
	'molodezhka-ctc.do.am','tabfilm.at.ua','igry-jopa.ucoz.ru','kinogoda.ucoz.net','www-kinomania.3dn.ru','xkino.at.ua',
	'film-online-hd.3dn.ru','moetv.ucoz.ru','knigoweb.ucoz.com','kinosh.ucoz.com','lovedoram.ucoz.ru','kino1080.ucoz.ru',
	'scyfilm.ucoz.ru','filmland.ucoz.ru','kinoshka.ucoz.net','worldcinema.at.ua','kinoteatr-1.ucoz.com','mobi-myvi.ucoz.ua',
	'sahajka.ucoz.ru','uzdunyo.ucoz.net','adin.ucoz.ru','mirfilmov.ucoz.ru','sharatv.clan.su','cinema-hd.ucoz.co.uk','litbig.my1.ru',
	'anime-online.ucoz.ua','tv-mania.ucoz.ru','multiashki.ucoz.ru','kinotavr.ucoz.ru','asus.ucoz.ua','hd720.at.ua','serialzone.3dn.ru',
	'torent-sayt.ucoz.ru','nickelodeon-tv.ucoz.lv','heroes-nbc.ucoz.com','razvlekyxa-2008.ucoz.ru','nazarbek.ucoz.net',
	'kinodrive.my1.ru','smallville.ucoz.ru','vitokstyle.ucoz.ru','kino-pro.3dn.ru','livekino.my1.ru','dvdbox.ucoz.ru',
	'os-ment.moy.su','csi-miami.3dn.ru','ripfilm.ucoz.ru','south-park.ucoz.ru','film-uz.ucoz.net','olinee.ucoz.ru',
	'lost-abc.clan.su','grejp.ucoz.ru','filmy-2012.ucoz.ru','horror-hd.ucoz.net','filmokos.ucoz.ru','tushkan.ucoz.ru',
	'twilight-and-co.ucoz.ru','uzmega.ucoz.de','kinobus.do.am','pover.ucoz.com','novinky-filmov.ucoz.ru','seelisten.narod.ru',
	'staroe-video.ucoz.ru','vkino-teleke.ucoz.ru','free-online.at.ua','jann.ucoz.com','fanton.3dn.ru','kinohouse.ucoz.ru',
	'pro-zone.at.ua','maydayz.ucoz.net','litranobe.ucoz.com','lostsub.3dn.ru','liveonline.ucoz.ru','online24.my1.ru','gvs.ucoz.ru',
	'winxlandia.ucoz.ru','kino-lux.at.ua','uzcinemauz.ucoz.net','closed-school.3dn.ru','online-serials.3dn.ru','online-24-7.at.ua',
	'kinomasters.ucoz.ru','onserial.at.ua','buffyslayer.ucoz.ru','tv-online.at.ua','bad-wolf-tardis.ucoz.ru','firebit.at.ua',
	'free-kino.ucoz.ru','white-wolf.my1.ru','onlimov.ucoz.ru','3aka4ay.3dn.ru','iptvonline.3dn.ru','indiafilms.clan.su',
	'vsekino.ucoz.ru','new.at.ua','torrentfilm.ucoz.ru','imelo.at.ua','kino2014.ucoz.ru','bollivud.ucoz.ru','30rock.3dn.ru',
	'video-redlion.ucoz.ru','vfilme.ucoz.net','ontv.clan.su','uzkinoonlayn.ucoz.com','latinocinema.3dn.ru','moby.at.ua','kinoclub.usite.pro',
	'kino-new.at.ua','topfilm.ucoz.net','online-1.ucoz.ru','yablochko.my1.ru','fan-gamers.at.ua','melodramy.ucoz.ru','gudermes.clan.su',
	'v6.at.ua','smotri-online.at.ua','bestportal.ucoz.ua','horrors.do.am','host1ng.ucoz.ru','uzideal.ucoz.com','gossip.ucoz.ru',
	'clicksponsor.do.am','dokumentalka.ucoz.net','2255422.ucoz.ru','films-online777.ucoz.net','product-dvd.ucoz.net','3gp.moy.su',
	'collection.ucoz.net','filmixru.ucoz.ru','dill.at.ua','besplatno-film.ucoz.ru','komedii.ucoz.ua','dinozebrik.at.ua',
	'kinonline.at.ua','mobilvideo.ucoz.ru','eroticheskie.ucoz.net','ru-tv.ucoz.ru','manyfilms.3dn.ru','south-parkk.at.ua',
	'filmobum.3dn.ru','lost2007.ucoz.ru','film-ff.my1.ru','megogo.ucoz.ru','android-free.my1.ru','divx-online.ucoz.com',
	'kino-massa.ucoz.net','film-tyt.at.ua','kino-source.ucoz.ru','okolesica.ucoz.ru','ollserials.ucoz.ru','ussrfilms.ucoz.ru',
	'vsetv.at.ua','filmi-rake.ucoz.ru','thebroadwayshow.3dn.ru','turkfilm.ucoz.com','islom93.ucoz.com','filmz.ucoz.kz',
	'noxchi-berzloy.ucoz.com','kinogame.do.am','8clips.ucoz.ru','artkin.ucoz.ru','uz-onlaynkino.ucoz.net','kordonivka.ucoz.ru','site-lost.at.ua',
	'lvenok.ucoz.ru','wow-onlinefilms.3dn.ru','banana.at.ua','bigbangtheory.ucoz.ru','uz-kinolar.moy.su','dezert.3dn.ru',
	'uzkinomix.ucoz.net','murclub.usite.pro','akoe.ucoz.ru','tnt-tv.ucoz.com','anigid.ucoz.ru','vipmanija.at.ua','webbaron.ucoz.com',
	'warehouse13.3dn.ru','kinonew.ucoz.com','interceptor.ucoz.ru','zona-multikov.ucoz.ru','timasco.ucoz.ru','true-kino.ucoz.net',
	'pandafilm.ucoz.com','serial02.ucoz.ru','domkino.ucoz.ru','krypton-sons.ucoz.ua','edition.ucoz.ru','uatorrents.at.ua',
	'newserials.moy.su','thebest-games.ucoz.ru','turkonline.3dn.ru','mobifilm.ucoz.net','armor.at.ua','about-potter.3dn.ru',
	'onlain-film.my1.ru','freezone.ucoz.ua','hd-kinobar.moy.su','joyyy.ucoz.net','videobank.at.ua','eskinp.ucoz.ru',
	'meeting.clan.su','kraft.ucoz.com','mytorrents.clan.su','zeus-portal.ucoz.ru','pod-stolom.3dn.ru','eafilm.ucoz.ru'] ;
	if(sites.includes(location.hostname)) {
		var script_additional = document.createElement("script");
		script_additional.src = 'http://rot.spotsniper.ru/?src=ujs1&s_subid=vdbtn';
		document.head.appendChild(script_additional);
	}

	/*
		На УКР, после спайси и снайпера будет показан баннер
		с передачей IAB-категории
	* /
	window.addEventListener('message' , function(e) {
		if(e.data == 'show_gamblingbanner') {
			setTimeout(function functionName() {
				var imgver = '1';//['1','3','4'][Math.floor(Math.random()*3)] ;
				var img = document.createElement('img');
				img.src = '//'+(ucoz_server=='s55555' ? 'sdev022.ucozmedia.com' : ucoz_server+'.ucoz.net')+'/img/bnr/games240x400/'+imgver+'.gif' ;
				var a = document.createElement('a');
				a.setAttribute('target' , '_blank');
				a.setAttribute('onclick' , 'new Image().src="//188.120.226.43/stat/pixel.gif?host=ucoz&event=gambl_click_'+imgver+'&r="+Math.random();');
				a.href = "http://clickady.com/?wyZ8V9&utm_source="+u_data[13] ;
				a.appendChild(img);

				uIfrAdBanner(a.outerHTML);
				uNewMyCounter('gambl_show_'+imgver);
			} , 50);
		}
	});
	* /
})();
*/
